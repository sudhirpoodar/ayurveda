<footer class="amp-wp-footer">
	<div>
    <div class="footer-copy"><?php echo magplus_get_opt('amp-footer-copyright-text'); ?></div>
	</div>
</footer>
