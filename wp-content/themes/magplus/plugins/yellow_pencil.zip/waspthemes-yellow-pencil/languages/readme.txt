Hi There,

To translate the plugin to your language, you need to use the PoEdit software.

PLEASE FOLLOW THESE STEPS
-----------------
1. download and install PoEdit.
2. Go to the plugin directory, open "yp.pot" file with PoEdit.
3. Translate words and sentences to your language and save files to the plugin directory > languages folder, the file name should be like this "yp-en_EN", "yp_fr_FR". etc.

Please send us the translated files if you want to help our development! :)
You can send the files to our email address: support@waspthemes.com